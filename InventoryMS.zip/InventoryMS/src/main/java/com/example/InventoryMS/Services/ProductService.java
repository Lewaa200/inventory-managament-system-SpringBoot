package com.example.InventoryMS.Services;

import com.example.InventoryMS.Models.ProductModel;
import com.example.InventoryMS.Models.UserModel;
import com.example.InventoryMS.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service

public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public List<ProductModel> getAllProducts() {
        return productRepository.findAll();
    }

    public List<ProductModel> getProductByUserId(Long userId){
        return productRepository.getAllByUserUserId(userId);
    }


    public ProductModel createOrUpdateProduct(ProductModel productModel,long userId){

        UserModel user = productModel.getUser();
        if (user == null) {
            user=new UserModel();
            user.setUserId(userId);
        }

        ProductModel existingProduct = productRepository.findByProductNameAndUserUserId(productModel.getProductName(), userId);
        if(existingProduct!=null){
            int newQuantity = existingProduct.getProductQuantity() + productModel.getProductQuantity();
            existingProduct.setProductQuantity(newQuantity);
            return productRepository.save(existingProduct);
        }else{
            productModel.setUser(user);
            return productRepository.save(productModel);}
    }

    public ProductModel createProduct(ProductModel product) {
        return productRepository.save(product);
    }

    public ProductModel updateProduct(Long id, ProductModel product) {
        Optional<ProductModel> existingProductOptional = productRepository.findById(id);
        if (existingProductOptional.isPresent()) {
            ProductModel existingProduct = existingProductOptional.get();
            existingProduct.setProductName(product.getProductName());
            existingProduct.setProductQuantity(product.getProductQuantity());
            existingProduct.setUser(product.getUser());
            return productRepository.save(existingProduct);
        } else {
            // Handle error, product not found
            return null;
        }
    }
    public ProductModel findByProductNameAndUserId(String productName, Long userId) {
        List<ProductModel> products = productRepository.findByProductName(productName);
        for (ProductModel product : products) {
            if (product.getUser().getUserId().equals(userId)) {
                return product;
            }
        }
        return null; // No product found for the given user ID
    }
    public void saveProduct(ProductModel product) {
        productRepository.save(product);
    }

    public void deleteProduct(ProductModel product) {
        productRepository.delete(product);
    }
public void DeleteProdByName(String productName){
        productRepository.deleteByProductName(productName);
}
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

}
