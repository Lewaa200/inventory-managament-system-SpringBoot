package com.example.InventoryMS.Services;

import com.example.InventoryMS.Models.UserModel;
import com.example.InventoryMS.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<UserModel> getAllUsers() {
        return userRepository.findAll();
    }

    public UserModel createUser(UserModel user) {

        if (userRepository.existsById(user.getUserId())) {
            return null;
        } else
            return userRepository.save(user);
    }

//    public boolean authenticateUser(String username,String password){
//        UserModel user = userRepository.findByUserName(username);
//        if (user != null && password.toString().equals(user.getPassword().toString())) {
//            return true; // Authentication successful
//        } else {
//            return false; // Authentication failed
//        }
//    }

    public boolean checkIfUserExists(String username, String password) {
        // Call the repository method to check if a user exists with the provided username and password
        // This could involve querying the database to find a matching user
        // You might use findByUsernameAndPassword method if such method exists in your repository
        UserModel user = userRepository.findByUserNameAndPassword(username, password);

        // Check if the user is not null, indicating that a user with the provided credentials exists
        return user != null;
    }

    public String getUsername(String username) {
        return String.valueOf(userRepository.findByUserName(username));
    }

    public UserModel getId(String userName){
        return userRepository.getUserModelByUserName(userName);
    }


    public UserModel updateUser(Long id, UserModel user) {
        Optional<UserModel> existingUserOptional = userRepository.findById(id);
        if (existingUserOptional.isPresent()) {
            UserModel existingUser = existingUserOptional.get();
            existingUser.setUserName(user.getUserName());
            existingUser.setPassword(user.getPassword());
            return userRepository.save(existingUser);
        } else {
            // Handle error, user not found
            return null;
        }
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }


    public boolean checkAndCreateUser(UserModel user) {
        String username = user.getUserName();

        // Check if username already exists in the database
        if (userRepository.existsByUserName(username)) {
            // Username already exists
            return false;
        }

        try {
            // Username does not exist, create the user
            userRepository.save(user);
            return true;
        } catch (DataIntegrityViolationException e) {
            // Catch any data integrity violation exceptions (e.g., unique constraint violation)
            e.printStackTrace();
            return false;
        }


    }
}
