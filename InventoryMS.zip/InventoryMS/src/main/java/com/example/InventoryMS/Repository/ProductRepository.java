package com.example.InventoryMS.Repository;

import com.example.InventoryMS.Models.ProductModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<ProductModel, Long> {

    List<ProductModel> getAllByUserUserId(@Param("userId") Long userId);
    ProductModel findByProductNameAndUserUserId(String productName, @Param("userId") Long userId);
    // You can add custom query methods here if needed
    ProductModel deleteByProductName(String productName);
        List<ProductModel> findByProductName(String productName);

}