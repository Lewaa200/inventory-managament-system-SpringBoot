package com.example.InventoryMS.Controllers;

import com.example.InventoryMS.Models.ProductModel;
import com.example.InventoryMS.Models.UserModel;
import com.example.InventoryMS.Services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping
    public List<ProductModel> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/user/{userId}")
    public List<ProductModel>getProductByUserId(@PathVariable Long userId){
        return productService.getProductByUserId(userId);
    }

    @PostMapping("/{userId}")
    public ProductModel createProduct(@RequestBody ProductModel product,@PathVariable long userId) {
        return productService.createOrUpdateProduct(product,userId);
    }

    @PutMapping("/{id}")
    public ProductModel updateProduct(@PathVariable Long id, @RequestBody ProductModel product) {
        return productService.updateProduct(id, product);
    }






    @DeleteMapping("/delete/{userId}/{productName}")
    public ResponseEntity<String> removeProductQuantity(
            @PathVariable Long userId,
            @PathVariable String productName,
            @RequestParam int quantityToRemove) {

        // Find the product by name and user ID
        ProductModel product = productService.findByProductNameAndUserId(productName, userId);

        if (product == null) {
            return new ResponseEntity<>("Product not found for the specified user", HttpStatus.NOT_FOUND);
        }

        // Check if the quantity to remove is greater than or equal to the product quantity
        if (quantityToRemove >= product.getProductQuantity()) {
            // Delete the product
            productService.deleteProduct(product);
            return new ResponseEntity<>("Product deleted", HttpStatus.OK);
        } else {
            // Update the product quantity
            product.setProductQuantity(product.getProductQuantity() - quantityToRemove);
            productService.saveProduct(product);
            return new ResponseEntity<>("Product quantity updated", HttpStatus.OK);
        }
    }






    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }

}
