package com.example.InventoryMS.Controllers;

import com.example.InventoryMS.Models.UserModel;
import com.example.InventoryMS.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/get")
    public List<UserModel> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/username/{username}")
    public String getUserByUsername(@PathVariable String username) {
        // Implementation to retrieve user by username
    return userService.getUsername(username);}


    @GetMapping("/getId/{userName}")
    public UserModel getId(@PathVariable String userName){
        return userService.getId(userName);
    }

//    @PostMapping("/login")
//    public ResponseEntity<String> loginUser(@RequestParam String userName, @RequestParam String password){
//
//        boolean authenticated = userService.authenticateUser(userName, password);
//        if(authenticated){
//            return ResponseEntity.ok("log succesfull");
//        }else
//            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("invalid user name or password");
//    }

    @GetMapping("/exists")
    public ResponseEntity<String> checkIfUserExists(@RequestParam String username, @RequestParam String password) {
        boolean userExists = userService.checkIfUserExists(username, password);
        if (userExists) {
            return ResponseEntity.ok("User exists");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User does not exist");
        }
    }

    @PostMapping
    public UserModel createUser(@RequestBody UserModel user) {
        return userService.createUser(user);
    }

    @PutMapping("/{id}")
    public UserModel updateUser(@PathVariable Long id, @RequestBody UserModel user) {
        return userService.updateUser(id, user);
    }



    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }



    @PostMapping("/checkAndCreate")
    public ResponseEntity<String> checkAndCreateUser(@RequestBody UserModel user) {
        if (userService.checkAndCreateUser(user)) {
            return ResponseEntity.ok("User created successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username already exists");
        }
    }


}
