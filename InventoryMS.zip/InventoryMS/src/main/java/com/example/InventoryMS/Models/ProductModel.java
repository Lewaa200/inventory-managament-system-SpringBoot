package com.example.InventoryMS.Models;



import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.CrossOrigin;

@Entity
@Table(name = "products")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class ProductModel {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long productId;

    @NotEmpty(message = "Product name cannot be empty")
    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_Quantity")
    private int productQuantity;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserModel user;


    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    public UserModel getUser() {
        return user;
    }

    public void setUser(UserModel user) {
        this.user = user;
    }
}



